import os
from pprint import pprint, pformat
import random
import string

# Questa è una funzione di utilità che crea una directory con una struttura e file casuali.


def crea_directory_esercizio(num_folders, num_files, max_depth, current_depth=0, root_path=None):
    if current_depth == 0:
        root_path = os.path.join(os.path.dirname(
            os.path.abspath(__file__)), "directory_esercizio_69")
    for i in range(num_folders):
        folder_name = ''.join(random.choices(string.ascii_lowercase, k=5))
        folder_path = os.path.join(root_path, folder_name)
        os.makedirs(folder_path, exist_ok=True)

        for j in range(num_files):
            file_name = ''.join(random.choices(
                string.ascii_lowercase, k=5))
            file_extension = random.choice(['.txt', '.md', '.csv'])
            file_path = os.path.join(
                folder_path, file_name + file_extension)
            with open(file_path, 'w') as file:
                file.write('This is a sample file.')

        if current_depth < max_depth:
            crea_directory_esercizio(
                num_folders, num_files, max_depth, current_depth + 1, folder_path)


def trim_path(path):
    """
    Ritorna il nome dell'ultimo file o directory nel percorso path.

    Esempio:
        trim_path("/home/user/file.txt") -> "file.txt"
        trim_path("/home/user/directory") -> "directory"
    """
    return os.path.basename(os.path.normpath(path))


def indice_file_txt(dir_path, dizionario=dict()):
    """
    Si implementi una funzione rappresenta_directory(directory) che dato il percorso assoluto di una directory,
    ritorna un dizionario in cui:
    - Le chiavi del dizionario sono i nomi dei file con estensione .txt
    - Il valore associato ad ogni chiave è il contenuto di tale file


    Esempio per la directory_esercizio_69 ritorna il seguente dizionario:
    {
        'amwgi.txt': 'This is a sample file.',
        'hhdix.txt': 'This is a sample file.',
        'kuhmp.txt': 'This is a sample file.',
        'lciny.txt': 'This is a sample file.'
    }

    Funzioni del modulo os utili:
        - os.listdir(path): ritorna la lista di tutti i nomi dei file e delle directory all'interno di path (nota bene: torna solo i nomi, non i percorsi assoluti)
        - os.path.isdir(path): ritorna True se path è una directory
        - os.path.join(path1, path2, ...): ritorna la concatenazione di path1, path2, ...

    Altri consigli:
        - Per stampare il dizionario in maniera più leggibile, si può utilizzare la funzione pprint del modulo pprint (già importato). Esempio: pprint(dizionario)
    """
    # Implementa la funzione
    pass


if __name__ == "__main__":
    random.seed(0)
    path_corrente = os.path.dirname(os.path.abspath(__file__))
    directory_esercizio = os.path.join(path_corrente, "directory_esercizio_69")
    if not os.path.exists(directory_esercizio):
        print(f'Creo la directory {directory_esercizio}')
        crea_directory_esercizio(num_folders=1, num_files=3, max_depth=2)
    print(f"La directory {trim_path(directory_esercizio)} esiste già, evito di crearla. Per forzare la creazione, cancellare la directory e riavviare il programma. \n ---------------------------------------")

    dizionario = indice_file_txt(directory_esercizio, dizionario={})

    soluzione = {'amwgi.txt': 'This is a sample file.',
                 'hhdix.txt': 'This is a sample file.',
                 'kuhmp.txt': 'This is a sample file.',
                 'lciny.txt': 'This is a sample file.'}

    assert dizionario == soluzione, f"Il dizionario non rappresenta l'indice dei file txt in {trim_path(directory_esercizio)}. Il dizionario ottenuto è: \n{pformat(dizionario)}"

    print(
        f'Il dizionario è il corretto indice dei file txt contenuti in {trim_path(directory_esercizio)}.')
