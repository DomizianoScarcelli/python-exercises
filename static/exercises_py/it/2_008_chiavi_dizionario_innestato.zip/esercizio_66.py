dizionario = {
    "a": 1,
    "b": 2,
    "c": 3,
    "d":
    {
        "e": 4,
        "f": 5,
        "g": 6,
        "h":
        {
            "i": 7,
            "j": 8,
            "k": 9
        }
    },
    "l": 10,
    "m": 11,
    "n": 12,
    "o": 13,
    "p": {
        "q": 14,
        "r": 15,
        "s": 16,
        "t": {
            "u": 17,
            "v": 18,
            "w": 19,
            "x": {
                "y": {
                    "z": 20
                }
            }
        }
    },
}


def chiavi_dizionari(dizionario, chiavi=set()):
    """
    Si implementi la funzione chiavi_dizionario(dizionario) che ritorna l'insieme
    delle chiavi del dizionario.

    Per il dizionario dato in input, la funzione deve ritornare l'insieme:

    {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
    'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z'}

    Consiglio: per capire se un elemento è un intero, si può usare la funzione
    isinstance(elemento, int) che ritorna True se elemento è un intero, False
    altrimenti.

    Allo stesso modo, per capire se un elemento è un dizionario, si può usare la
    funzione isinstance(elemento, dict) che ritorna True se elemento è un dizionario,
    False altrimenti.

    """
    #TODO: implementa qua la tua funzione
    pass


if __name__ == "__main__":
    chiavi = chiavi_dizionari(dizionario)
    chiavi_corrette = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
                       'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't',
                       'u', 'v', 'w', 'x', 'y', 'z'}

    assert chiavi == chiavi_corrette, f"""
    Chiavi errate:
    Le chiavi da te generate: {chiavi}
    Le chiavi corrette: {chiavi_corrette}
    """

    print(f"Le chiavi da te generate sono {chiavi}, l'esercizio è corretto!")
